import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { usePortfolio } from '../contexts/PortfolioContext';
import { ExternalLink, ChevronRight } from 'lucide-react';

const ProjectsSection: React.FC = () => {
  const { data } = usePortfolio();
  const projects = data.projects || [];
  const targetRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: targetRef,
  });

  // Calculate the horizontal movement. We have 4 cards, so we need to move roughly -75% of the total track width.
  // We use -x to move it left as we scroll down.
  const x = useTransform(scrollYProgress, [0, 1], ["0%", "-75%"]);

  return (
    <section ref={targetRef} id="projects" className="relative w-full h-[400vh]">
      <div className="sticky top-0 h-screen w-full flex flex-col justify-center items-start overflow-hidden bg-transparent">
        
        <div className="w-full px-8 md:px-16 lg:px-24 mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl uppercase">
              FEATURED WEB DEVELOPMENT DEMO PROJECTS
            </h2>
            <div className="mt-4 h-1 w-20 rounded-full bg-blue-600"></div>
          </motion.div>
        </div>

        {/* The horizontal scrolling track */}
        <div className="w-full overflow-hidden">
          <motion.div 
            style={{ x }} 
            className="flex w-[400vw] items-center pl-8 md:pl-16 lg:pl-24 pb-20"
          >
            {projects.map((project, idx) => (
              <div key={idx} className="w-[85vw] sm:w-[70vw] md:w-[50vw] lg:w-[40vw] flex-shrink-0 pr-8 md:pr-12">
                <div className="group flex flex-col overflow-hidden rounded-[2rem] bg-[#0A0F1C]/90 backdrop-blur-md border border-white/5 shadow-2xl transition-all hover:-translate-y-2 hover:shadow-blue-500/10">
                  {project.image && (
                    <div className="w-full aspect-[16/10] relative overflow-hidden bg-black/50 border-b border-white/5">
                      <img 
                        src={project.image} 
                        alt={project.title} 
                        className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
                      />
                    </div>
                  )}
                
                <div className="p-8 md:p-10 flex flex-col flex-grow">
                  <h3 className="mb-4 text-3xl font-black text-white uppercase tracking-tight">
                    {project.title.split('–')[0].trim()}
                  </h3>
                  
                  <p className="mb-8 text-lg text-slate-300 leading-relaxed">
                    {project.bullets?.[0] || "A comprehensive web application demonstrating modern development practices."}
                  </p>
                  
                  <div className="mb-10 flex flex-wrap gap-3">
                    {project.tech.split(',').map((t, i) => (
                      <span 
                        key={i} 
                        className="px-5 py-2 rounded-full border border-white/10 text-slate-300 text-sm font-semibold bg-white/5 backdrop-blur-sm"
                      >
                        {t.trim()}
                      </span>
                    ))}
                  </div>
                  
                  <div className="mt-auto flex flex-wrap items-center gap-4">
                    <button className="flex items-center gap-2 px-8 py-3.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-bold transition-colors shadow-lg shadow-blue-500/25">
                      View Case Study <ChevronRight className="w-5 h-5" />
                    </button>
                    <a 
                      href={project.url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="flex items-center gap-2 px-8 py-3.5 rounded-full border border-white/20 hover:bg-white/10 text-white font-bold transition-colors"
                    >
                      Live Demo <ExternalLink className="w-5 h-5" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </motion.div>
        </div>

      </div>
    </section>
  );
};

export default ProjectsSection;
